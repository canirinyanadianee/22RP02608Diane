<?php
include('stconn.php');

if(isset($_POST['update'])){

    $i=$_POST['id'];
    $a=$_POST['st_names'];
    $b=$_POST['emails'];
    $c=$_POST['reg_no'];
    $d=$_POST['phonenumber'];
    $res=mysqli_query($link,"UPDATE `student` SET `st_names`='$a',`emails`='$b',`regno`='$c',`phonenumber`='$d' WHERE `st_id`='$i' ");
   if($res){
    echo"success student update";
    header('location:home.php');
   }
   else{
    echo"not update";
   }
}
?>



<html>
<head><title></title>
<style>
    table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #00796b;
    color: white;
}

td {
    color: #555;
}

tr:hover {
    background-color: #f1f1f1;
}

input[type="submit"] {
    background-color: #00796b;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-bottom: 20px;
}

input[type="submit"]:hover {
    background-color: #004d40;
}

a {
    color: #00796b;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
</style>

</head>
<body>
<form action="" method="POST"><center>
<h1><b><u>ADMIN UPDATE<u></b></h1><br>
<table>
<tr><td>Id</td><td><input type="number" name="id" ></td></tr>
    <tr><td>Names</td><td><input type="text" name="st_names" ></td></tr>
    <tr><td>Email</td><td><input type="text" name="emails" ></td></tr>
    <tr><td>Regno</td><td><input type="text" name="reg_no" ></td></tr>
    <tr><td>PhoneNumber</td><td><input type="text" name="phonenumber" ></td></tr>
    <tr><td></td><td><input type="submit"  name="update" value="update" ></td></tr>

</table>
</center>
</Form>



</body>


</html>