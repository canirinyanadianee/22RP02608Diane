<?php
$link=mysqli_connect("localhost","root","","school");
// if($link==true){
//     echo"successfully";
// }
// else{
//     echo"fails";
// }
?>