<?php
include('stconn.php');

if(isset($_POST['delete'])){

    $i=$_POST['id'];
    // $a=$_POST['st_names'];
    // $b=$_POST['emails'];
    // $c=$_POST['reg_no'];
    // $d=$_POST['phonenumber'];
    $res=mysqli_query($link,"DELETE FROM student WHERE st_id='$i'");
   if($res){
    echo"success student deleted";
    header('location:home.php');
   }
   else{
    echo"notdelete";
   }
}
?>



<html>
<head><title></title></head>
<body>
<form action="" method="POST"><center>
<h1><b><u>ADMIN DELETE<u></b></h1><br>
<table>
<tr><td>Id</td><td><input type="number" name="id" ></td></tr>
    <!-- <tr><td>Names</td><td><input type="text" name="st_names" ></td></tr>
    <tr><td>Email</td><td><input type="text" name="emails" ></td></tr>
    <tr><td>Regno</td><td><input type="text" name="reg_no" ></td></tr>
    <tr><td>PhoneNumber</td><td><input type="text" name="phonenumber" ></td></tr> -->
    <tr><td></td><td><input type="submit"  name="delete" value="delete" ></td></tr>

</table>
</center>
</Form>



</body>


</html>