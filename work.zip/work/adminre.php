<?php
include('stconn.php');

if(isset($_POST['register'])){
$a=$_POST['admin_names'];
$b=$_POST['password'];
$c=$_POST['emails'];
$result=mysqli_query($link,"INSERT into admin values(NULL,'$a','$b','$c')");
// $sql="INSERT INTO admin (admin_id,admin_names,password,emails) VALUES('$a','$b',$c')";
// $result=mysqli_query($link,$sql);
if($result){
    echo"successfully Registered";
    header('location:index.php');
}
else{
  echo "Failed ton insert";
}
}
?>
<script> alert("successfully");</script>





<html>
<head><title></title>
<style>
  table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #00796b;
    color: white;
}

td {
    color: #555;
}

tr:hover {
    background-color: #f1f1f1;
}

input[type="submit"] {
    background-color: #00796b;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-bottom: 20px;
}

input[type="submit"]:hover {
    background-color: #004d40;
}

a {
    color: #00796b;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<form action="" method="POST"><center>
<h1><b><u>ADMIN REGISTRATION<u></b></h1><br>
<table>
    <tr><td>Names</td><td><input type="text" name="admin_names" ></td></tr>
    <tr><td>Password</td><td><input type="password" name="password" ></td></tr>
    <tr><td>Email</td><td><input type="text" name="emails" ></td></tr>
    <tr><td></td><td><input type="submit"  name="register" value="register" ></td></tr>

</table>
</center>
</Form>



</body>


</html>