<html>
    <head><title></title>
<style>
    /* style.css */

body {
    font-family: Arial, sans-serif;
    background-color: grey;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    flex-direction: column;
}

h1 {
    color: brown;
    margin-bottom: 40px;
    font-size: 36px;
    text-shadow: 1px 1px 2px #000;
}

button {
    background-color: black;
    color: white;
    padding: 15px 25px;
    margin: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 18px;
    transition: background-color 0.3s ease;
    text-shadow: 1px 1px 2px #000;
}

button:hover {
    background-color: #darkblue;
}

button a {
    color: white;
    text-decoration: none;
}

button a:hover {
    text-decoration: underline;
}

</style>
</head>
<body>
  <center> <h1><b><i><u>STUDENT MANAGEMENT SYSTEM</u></i></b></h1>
  <br>
  <button><a href="student.php">ADD  STUDENT</a></button>
  <button><a href="select.php">VIEW THE STUDENT</a></button>
  <button><a href="update.php">UPDATE THE STUDENT</a></button>
  <button><a href="delete.php">DELETE</a></button>
  <button> <a href="logout.php">LOGOUT</a></button>



  </center> </body>

</html>