<?php
session_start();

include('stconn.php');
if (isset($_POST['login'])){
$a=$_POST['admin_names'];
$b=$_POST['password'];
$result=mysqli_query($link,"SELECT * FROM admin WHERE admin_names='$a'");
$count1=mysqli_num_rows($result);
$fetch=mysqli_fetch_array($result);

if($count1==0){
    echo"invalid username";
    header('location:login.php');
}
else{
    if($fetch['admin_names']==$a && $fetch['password']==$b){
        $_SESSION['admin_names']=$username;
        header('location:home.php');
    }
    else{
        echo"invalid username or password";
    }
}
}
?>

<html>
<head><title>

</title>
<link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
<form action="" method="POST">
    <div class="login-container">
<h1><b><u>ADMIN REGISTRATION<u></b></h1><br>
<table>
    <tr><td>Names</td><td><input type="text" name="admin_names" ></td></tr>
    <tr><td>Password</td><td><input type="password" name="password" ></td></tr>
    
    <tr><td></td><td><input type="submit"  name="login" value="login" ></td></tr>

</table>
<p>if you do not have an accout 
<a href="adminre.php">click here</a></p>
</div>
</Form>



</body>


</html>