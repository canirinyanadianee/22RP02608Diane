<?php
    include('stconn.php');
?>
 <html>
<head><title></title>
<style>/* style.css */

body {
    font-family: Arial, sans-serif;
    background-color: #e0f7fa;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    background-color: #ffffff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    width: 80%;
    max-width: 800px;
}

h1 {
    color: #00796b;
    margin-bottom: 20px;
    font-size: 24px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #00796b;
    color: white;
}

td {
    color: #555;
}

tr:hover {
    background-color: #f1f1f1;
}

input[type="submit"] {
    background-color: #00796b;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-bottom: 20px;
}

input[type="submit"]:hover {
    background-color: #004d40;
}

a {
    color: #00796b;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
</style>

</head>
<body><div class="container">
<form action="" method="POST">
<h1><b><u>student view<u></b></h1><br>
<input type="submit"  name="view" value="view" >
<table border="1"><center>
    <tr>
        <td>STUDENT NAME</td>
        <td>Emails</td>
        <td>REGISTRATION NUMBER</td>
        <td>PHONE NUMBER</td>
        <td colspan="2">ACTION</td>
    </tr>
    <tr>
        <?php
        if (isset($_POST['view'])){
            $result=mysqli_query($link,"SELECT * FROM student");
        while($fetch=mysqli_fetch_array($result)){
            ?>
            <tr>
                <td><?php echo $fetch['st_names'];?></td>
                <td><?php echo $fetch['emails'];?></td>
                <td><?php echo $fetch['regno'];?></td>
                <td><?php echo $fetch['phonenumber'];?></td>
                <td>  <a href="update.php?st_id=<?php echo $fetch['st_id']?>"> update</td>
                <td><a href="delete.php?st_id=<?php echo $fetch['st_id']?>">delete</td>
                <td><a href="student.php?st_id=<?php echo $fetch['st_id']?>">add </td>
        </tr>
        <?php
        }}
        ?>
    </tr>
</table>

</Form></div>
</body>
</html>